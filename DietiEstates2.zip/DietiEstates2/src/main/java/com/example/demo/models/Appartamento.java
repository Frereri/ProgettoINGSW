package com.example.demo.models;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;


@Entity
@DiscriminatorValue("APPARTAMENTO")
public class Appartamento extends Immobile {

}
