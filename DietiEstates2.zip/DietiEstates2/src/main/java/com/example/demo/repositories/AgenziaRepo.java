package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.Agenzia;

public interface AgenziaRepo extends JpaRepository<Agenzia, Integer>{

//	Agenzia findById(String idAgenzia);
}
