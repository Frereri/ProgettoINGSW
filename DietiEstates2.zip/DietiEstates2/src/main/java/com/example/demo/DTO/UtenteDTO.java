package com.example.demo.DTO;

import java.util.UUID;

public abstract class UtenteDTO {

	private UUID idUtente;
    private String nome;
    private String cognome;
    private String email;
    private String ruolo;
	
    public UtenteDTO() {
		super();
	}
    
	public UUID getIdUtente() {
		return idUtente;
	}
	
	public void setIdUtente(UUID idUtente) {
		this.idUtente = idUtente;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCognome() {
		return cognome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getRuolo() {
		return ruolo;
	}
	
	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}
    
    
}
