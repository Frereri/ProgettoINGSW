package com.example.demo.models;

import java.util.List;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="cliente", schema="dietiestates")
@AttributeOverride(name = "id", column = @Column(name = "idcliente"))
public class Cliente extends Utente {
	
	@OneToMany(mappedBy = "cliente")
	private List<Offerta> offerte;

	public Cliente() {
		super();
	}

	public Cliente(List<Offerta> offerte) {
		super();
		this.offerte = offerte;
	}

	public List<Offerta> getOfferte() {
		return offerte;
	}

	public void setOfferte(List<Offerta> offerte) {
		this.offerte = offerte;
	}

	
}
