package com.example.demo.DTO;

public class AmministratoreDTO extends UtenteDTO{

}
