package com.example.demo.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.example.demo.DTO.ImmobileDTO;
import com.example.demo.models.Appartamento;
import com.example.demo.models.Immobile;
import com.example.demo.models.Villa;

@Mapper(componentModel = "spring")
public interface IImmobileMapper {

	@Mapping(source = "agenzia.idAgenzia", target = "idAgenzia")
    @Mapping(source = "agenzia.nomeAgenzia", target = "nomeAgenzia")
    ImmobileDTO immobiletoImmobileDTO(Immobile immobile);

	@Mapping(target = "agenzia", ignore = true) 
    @Mapping(target = "offerte", ignore = true)
    Appartamento immobileDTOtoAppartamento(ImmobileDTO immobileDTO);

    @Mapping(target = "agenzia", ignore = true) 
    @Mapping(target = "offerte", ignore = true)
    Villa immobileDTOtoVilla(ImmobileDTO immobileDTO);
}