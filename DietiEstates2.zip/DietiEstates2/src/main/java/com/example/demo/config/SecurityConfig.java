package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
//            .csrf(csrf -> csrf.disable()) // Disabilitiamo CSRF per le API REST
//            .authorizeHttpRequests(auth -> auth
//                // Permettiamo a tutti di accedere agli endpoint di autenticazione
//                .requestMatchers("/api/auth/**").permitAll() 
//                // Permettiamo l'accesso a Swagger/OpenAPI se lo usi per testare
//                .requestMatchers("/v3/api-docs/**", "/swagger-ui/**").permitAll()
//                // Tutte le altre richieste richiedono che l'utente sia autenticato
//                .anyRequest().authenticated()
//            )
//            // Configuriamo il server come Resource Server OAuth2 che accetta JWT
//            .oauth2ResourceServer(oauth2 -> oauth2
//                .jwt(Customizer.withDefaults())
//            );
	        .csrf(csrf -> csrf.disable())
	        .authorizeHttpRequests(auth -> auth
	            // Assicurati che TUTTO ciò che sotto /api/auth/ sia libero
	            .requestMatchers("/api/auth/**").permitAll()
	            .requestMatchers("/api/utente/**").authenticated()
	            .requestMatchers("/v3/api-docs/**", "/swagger-ui/**").permitAll()
	            .anyRequest().authenticated()
	        )
	        .oauth2ResourceServer(oauth2 -> oauth2.jwt(jwt -> {}));
        
        return http.build();
    }
}
