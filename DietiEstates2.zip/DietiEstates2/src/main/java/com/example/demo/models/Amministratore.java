package com.example.demo.models;

import java.util.List;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name="amministratore")
@AttributeOverride(name = "id", column = @Column(name = "idamministratore"))
public class Amministratore extends Utente{

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name= "idamministratore")
//	private Integer idAmministratore;
	
	@Column(name= "passwordadmin")
	private String passwordAdmin;

	@OneToMany(mappedBy = "amministratore")
	private List<Gestore> gestori;
	
	public Amministratore() {
		super();
	}

	public Amministratore(Integer idAmministratore, String passwordAdmin, List<Gestore> gestori) {
		super();
//		this.idAmministratore = idAmministratore;
		this.passwordAdmin = passwordAdmin;
		this.gestori = gestori;
	}

//	public Integer getIdAmministratore() {
//		//return idAmministratore;
//		return super.getIdGestore();
//	}

//	public void setIdAmministratore(Integer idAmministratore) {
//		this.idAmministratore = idAmministratore;
//	}

	public Integer getIdAmministratore() {
		return this.getId();
	}
	
	public String getPasswordAdmin() {
		return passwordAdmin;
	}

	public void setPasswordAdmin(String passwordAdmin) {
		this.passwordAdmin = passwordAdmin;
	}

	public List<Gestore> getGestori() {
		return gestori;
	}

	public void setGestori(List<Gestore> gestori) {
		this.gestori = gestori;
	}

	
}
