package com.example.demo.services;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.DTO.AgenteDTO;
import com.example.demo.DTO.ImmobileDTO;
import com.example.demo.DTO.OffertaDTO;
import com.example.demo.mapper.IImmobileMapper;
import com.example.demo.mapper.IOffertaMapper;
import com.example.demo.mapper.IUtenteMapper;
import com.example.demo.models.Agente;
import com.example.demo.models.Immobile;
import com.example.demo.models.Offerta;
import com.example.demo.models.StoricoOfferta;
import com.example.demo.repositories.AgenteRepo;
import com.example.demo.repositories.ImmobileRepo;
import com.example.demo.repositories.OffertaRepo;
import com.example.demo.repositories.StoricoRepo;

@Service
public class AgenteService {

	@Autowired
    private AgenteRepo agenteRepo;
	
    @Autowired
    private ImmobileRepo immobileRepo;
    
    @Autowired
    private OffertaRepo offertaRepo;
    
    @Autowired
    private StoricoRepo storicoRepo;
    
    @Autowired
    private IImmobileMapper immobileMapper;
    
    @Autowired
    private IOffertaMapper offertaMapper;
    
    @Autowired
    private IUtenteMapper utenteMapper;

    public AgenteDTO getProfiloAgente(UUID idAgente) {
        Agente agente = agenteRepo.findById(idAgente)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Agente non trovato"));
        return utenteMapper.toAgenteDTO(agente);
    }
    
    public ImmobileDTO caricaImmobile(ImmobileDTO dto, UUID idAgente) {
        Agente agente = agenteRepo.findById(idAgente)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Agente non trovato"));

        Immobile immobile;
        if ("VILLA".equalsIgnoreCase(dto.getTipoImmobile())) {
            immobile = immobileMapper.immobileDTOtoVilla(dto);
        } else {
            immobile = immobileMapper.immobileDTOtoAppartamento(dto);
        }

        immobile.setAgente(agente);
        immobile.setAgenzia(agente.getAgenzia());
        
        // Logica Geoapify (Placeholder)
        checkServiziZona(immobile);

        return immobileMapper.immobileToDTO(immobileRepo.save(immobile));
    }

    private void checkServiziZona(Immobile immobile) {
        // Simulazione API: se ci sono coordinate, attiviamo i flag
        if (immobile.getLatitudine() != null && immobile.getLongitudine() != null) {
            immobile.setVicinoScuole(true);
            immobile.setVicinoParchi(true);
        }
    }

    public OffertaDTO inserisciOffertaEsterna(OffertaDTO dto, Integer idImmobile) {
        Immobile immobile = immobileRepo.findById(idImmobile)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Immobile non trovato"));

        Offerta offerta = offertaMapper.dtoToOfferta(dto);
        offerta.setImmobile(immobile);
        offerta.setOffertaEsterna(true);
        offerta.setPrezzoOriginale(immobile.getPrezzo());
        
        return offertaMapper.offertaToDTO(offertaRepo.save(offerta));
    }
    
    public OffertaDTO gestisciOfferta(Integer idOfferta, String stato, Double prezzo, String nota, UUID idAutore) {
        Offerta offerta = offertaRepo.findById(idOfferta)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        StoricoOfferta log = new StoricoOfferta();
        log.setOfferta(offerta);
        log.setStatoPrecedente(offerta.getStato());
        log.setNuovoStato(stato.toUpperCase());
        log.setPrezzoScambiato(prezzo != null ? prezzo : offerta.getPrezzoOfferto());
        log.setNota(nota);
        log.setAutoreAzione(idAutore);

        storicoRepo.save(log);

        offerta.setStato(stato.toUpperCase());
        if (prezzo != null) offerta.setPrezzoControfferta(prezzo);
        
        return offertaMapper.offertaToDTO(offertaRepo.save(offerta));
    }
}
