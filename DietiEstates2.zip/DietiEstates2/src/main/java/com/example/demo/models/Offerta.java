package com.example.demo.models;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Offerta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idofferta")
    private Integer idOfferta;
	
	@Column(name="prezzoofferto")
    private double prezzoOfferto;
    
    @Column(name="dataofferta", nullable = false)
    private LocalDate dataOfferta;
    
    @Column(name="stato", nullable = false, length = 30)
    private String stato;
    
    @Column(name="controfferta")
    private Double controfferta;
    
    @Column(name="prezzoproposto")
    private double prezzoProposto;
    
    @ManyToOne
    @JoinColumn(name = "idcliente", nullable = false)
	private Cliente cliente;
    
    @ManyToOne
    @JoinColumn(name = "idimmobile", nullable = false)
	private Immobile immobile;

	public Offerta() {
		super();
	}

	public Offerta(Integer idOfferta, double prezzoOfferto, LocalDate dataOfferta, String stato, Double controfferta,
			double prezzoProposto, Cliente idCliente, Immobile idImmobile) {
		super();
		this.idOfferta = idOfferta;
		this.prezzoOfferto = prezzoOfferto;
		this.dataOfferta = dataOfferta;
		this.stato = stato;
		this.controfferta = controfferta;
		this.prezzoProposto = prezzoProposto;
		this.cliente = idCliente;
		this.immobile = idImmobile;
	}

	public Integer getIdOfferta() {
		return idOfferta;
	}

	public void setIdOfferta(Integer idOfferta) {
		this.idOfferta = idOfferta;
	}

	public double getPrezzoOfferto() {
		return prezzoOfferto;
	}

	public void setPrezzoOfferto(double prezzoOfferto) {
		this.prezzoOfferto = prezzoOfferto;
	}

	public LocalDate getDataOfferta() {
		return dataOfferta;
	}

	public void setDataOfferta(LocalDate dataOfferta) {
		this.dataOfferta = dataOfferta;
	}

	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}

	public Double getControfferta() {
		return controfferta;
	}

	public void setControfferta(Double controfferta) {
		this.controfferta = controfferta;
	}

	public double getPrezzoProposto() {
		return prezzoProposto;
	}

	public void setPrezzoProposto(double prezzoProposto) {
		this.prezzoProposto = prezzoProposto;
	}

	public Cliente getIdCliente() {
		return cliente;
	}

	public void setIdCliente(Cliente idCliente) {
		this.cliente = idCliente;
	}

	public Immobile getIdImmobile() {
		return immobile;
	}

	public void setIdImmobile(Immobile idImmobile) {
		this.immobile = idImmobile;
	}
    
    
}
