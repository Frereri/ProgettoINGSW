package com.example.demo.mapper;

import org.mapstruct.Mapping;

import com.example.demo.DTO.AgenteDTO;
import com.example.demo.DTO.ClienteDTO;
import com.example.demo.DTO.GestoreDTO;
import com.example.demo.DTO.UtenteDTO;
import com.example.demo.models.Agente;
import com.example.demo.models.Cliente;
import com.example.demo.models.Gestore;
import com.example.demo.models.Utente;

public interface IUtenteMapper {

	default UtenteDTO toDTO(Utente utente) {
        if (utente instanceof Agente) return toAgenteDTO((Agente) utente);
        if (utente instanceof Gestore) return toGestoreDTO((Gestore) utente);
        if (utente instanceof Cliente) return toClienteDTO((Cliente) utente);
        // ... altri ruoli
        return null;
    }

    @Mapping(source = "agenzia.idAgenzia", target = "idAgenzia")
    @Mapping(source = "agenzia.nomeAgenzia", target = "nomeAgenzia")
    AgenteDTO toAgenteDTO(Agente agente);

    @Mapping(source = "agenzia.idAgenzia", target = "idAgenzia")
    @Mapping(source = "agenzia.nomeAgenzia", target = "nomeAgenzia")
    GestoreDTO toGestoreDTO(Gestore gestore);

    ClienteDTO toClienteDTO(Cliente cliente);
}
