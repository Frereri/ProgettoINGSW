package com.example.demo.services;

import com.example.demo.DTO.ImmobileDTO;
import com.example.demo.mapper.IImmobileMapper;
import com.example.demo.models.Agenzia;
import com.example.demo.models.Immobile;
import com.example.demo.repositories.AgenziaRepo;
import com.example.demo.repositories.ImmobileRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ImmobileService {

    @Autowired
    private ImmobileRepo repo;
    
    @Autowired
    private AgenziaRepo agenziaRepo;
    
    @Autowired
    private IImmobileMapper mapper;

    public List<Immobile> getAllImmobili() {
        return repo.findAll();
    }

    public Immobile saveImmobileFromDTO(ImmobileDTO dto) {
    	
        Agenzia agenzia = agenziaRepo.findById(dto.getIdAgenzia())
                .orElseThrow(() -> new RuntimeException("Agenzia non trovata con ID: " + dto.getIdAgenzia()));

        Immobile immobile;

        if ("VILLA".equalsIgnoreCase(dto.getTipoImmobile())) {
            immobile = mapper.immobileDTOtoVilla(dto);
        } else if ("APPARTAMENTO".equalsIgnoreCase(dto.getTipoImmobile())) {
            immobile = mapper.immobileDTOtoAppartamento(dto);
        } else {
            throw new IllegalArgumentException("Tipo immobile non valido");
        }

        immobile.setAgenzia(agenzia);

        return repo.save(immobile);
    }
    
}