package com.example.demo.controllers;

public class ImmobileController {

}
