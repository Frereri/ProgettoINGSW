package com.example.demo.controllers;

import com.example.demo.DTO.ImmobileDTO;
import com.example.demo.mapper.IImmobileMapper;
import com.example.demo.models.Immobile;
import com.example.demo.services.ImmobileService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/immobili")
public class ImmobileController {

    @Autowired
    private ImmobileService service;
    
    @Autowired
    private IImmobileMapper mapper;
    
    @GetMapping
    public ResponseEntity<List<ImmobileDTO>> getAll() {
    	try {
            List<Immobile> immobili = service.getAllImmobili();            

            if (immobili.isEmpty()) 
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);

            
            List<ImmobileDTO> dto = immobili.stream()
                    .map(mapper::immobiletoImmobileDTO)
                    .toList();

            return ResponseEntity.ok(dto);
            
        } catch (Exception e) {        	
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
    
    @PostMapping
    public ResponseEntity<?> create(@RequestBody ImmobileDTO dto) {
        try {
        	
            Immobile salvato = service.saveImmobileFromDTO(dto);
            return new ResponseEntity<>(mapper.immobiletoImmobileDTO(salvato), HttpStatus.CREATED);
        
        } catch (RuntimeException e) {        	
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        
        } catch (Exception e) {	
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore: " + e.getMessage());
        }
    }
}