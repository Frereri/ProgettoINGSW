package com.example.demo.models;

public class Villa extends Immobile{

}
