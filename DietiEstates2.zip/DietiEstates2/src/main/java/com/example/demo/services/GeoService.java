package com.example.demo.services;

import java.util.List;
import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service 
public class GeoService {
	
	private final String API_KEY = "LA_TUA_CHIAVE_GEOAPIFY";
    private final RestTemplate restTemplate = new RestTemplate();

    public boolean isNear(Double lat, Double lon, String category) {
        // Raggio di 500 metri
        String url = String.format(
            "https://api.geoapify.com/v2/places?categories=%s&filter=circle:%f,%f,500&limit=1&apiKey=%s",
            category, lon, lat, API_KEY
        );

        try {
        	ResponseEntity<Map<String, Object>> responseEntity = restTemplate.exchange(
    		    url, 
    		    HttpMethod.GET, 
    		    null, 
    		    new ParameterizedTypeReference<Map<String, Object>>() {}
    		);
    		Map<String, Object> response = responseEntity.getBody();
    		List<?> features = (List<?>) response.get("features");
            return !features.isEmpty();
        } catch (Exception e) {
            System.err.println("Errore Geoapify: " + e.getMessage());
            //return false;
            return true;
        }
    }

	public GeoService() {
		// TODO Auto-generated constructor stub
	}

}
