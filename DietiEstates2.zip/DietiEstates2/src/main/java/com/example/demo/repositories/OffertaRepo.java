package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.Offerta;

public interface OffertaRepo extends JpaRepository<Offerta, Integer>{

}
