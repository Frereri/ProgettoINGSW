package com.example.demo.services;

public class OffertaService {

}
