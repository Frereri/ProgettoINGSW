package com.example.demo.repositories;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.models.Immobile;

public interface ImmobileRepo extends JpaRepository<Immobile, Integer>{

	// Ricerca avanzata: Città + Prezzo compreso + Contratto
    List<Immobile> findByCittaIgnoreCaseAndPrezzoBetweenAndTipoContratto(
        String citta, double prezzoMin, double prezzoMax, String tipoContratto);

    // Ricerca per posizione geografica
    @Query("SELECT i FROM Immobile i WHERE i.latitudine BETWEEN :minLat AND :maxLat " +
           "AND i.longitudine BETWEEN :minLon AND :maxLon")
    List<Immobile> findByLocationRange(@Param("minLat") Double minLat, @Param("maxLat") Double maxLat, 
                                       @Param("minLon") Double minLon, @Param("maxLon") Double maxLon);
}
