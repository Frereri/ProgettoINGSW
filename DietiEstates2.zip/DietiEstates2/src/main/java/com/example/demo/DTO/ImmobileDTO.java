package com.example.demo.DTO;

public class ImmobileDTO {

	private Integer idImmobile;
    private String titolo;
    private String indirizzo;
    private Double prezzo;
    private String tipoImmobile;
    private Integer idAgenzia;
    private String nomeAgenzia;
    private String immagine;
    private String descrizione;
    private Integer numeroStanze;
    private String classeEnergetica;
    private boolean climatizzazione;
    private boolean boxAuto;
    private boolean terrazzo;
    private double dimensione;

    // Campi specifici per Appartamento
    private String piano;
    private boolean ascensore;
    private boolean portineria;

    // Campi specifici per Villa
    private boolean giardino;
    private boolean piscina;
    
	public ImmobileDTO() {
		// TODO Auto-generated constructor stub
	}

	public Integer getIdImmobile() {
		return idImmobile;
	}

	public void setIdImmobile(Integer idImmobile) {
		this.idImmobile = idImmobile;
	}
	
	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public Double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(Double prezzo) {
		this.prezzo = prezzo;
	}

	public String getTipoImmobile() {
		return tipoImmobile;
	}

	public void setTipoImmobile(String tipoImmobile) {
		this.tipoImmobile = tipoImmobile;
	}

	public Integer getIdAgenzia() {
		return idAgenzia;
	}

	public void setIdAgenzia(Integer idAgenzia) {
		this.idAgenzia = idAgenzia;
	}

	public String getNomeAgenzia() {
		return nomeAgenzia;
	}

	public void setNomeAgenzia(String nomeAgenzia) {
		this.nomeAgenzia = nomeAgenzia;
	}

	public String getImmagine() {
		return immagine;
	}

	public void setImmagine(String immagine) {
		this.immagine = immagine;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Integer getNumeroStanze() {
		return numeroStanze;
	}

	public void setNumeroStanze(Integer numeroStanze) {
		this.numeroStanze = numeroStanze;
	}

	public String getClasseEnergetica() {
		return classeEnergetica;
	}

	public void setClasseEnergetica(String classeEnergetica) {
		this.classeEnergetica = classeEnergetica;
	}

	public boolean isClimatizzazione() {
		return climatizzazione;
	}

	public void setClimatizzazione(boolean climatizzazione) {
		this.climatizzazione = climatizzazione;
	}

	public boolean isBoxAuto() {
		return boxAuto;
	}

	public void setBoxAuto(boolean boxAuto) {
		this.boxAuto = boxAuto;
	}

	public boolean isTerrazzo() {
		return terrazzo;
	}

	public void setTerrazzo(boolean terrazzo) {
		this.terrazzo = terrazzo;
	}

	public double getDimensione() {
		return dimensione;
	}

	public void setDimensione(double dimensione) {
		this.dimensione = dimensione;
	}

	public String getPiano() {
		return piano;
	}

	public void setPiano(String piano) {
		this.piano = piano;
	}

	public boolean isAscensore() {
		return ascensore;
	}

	public void setAscensore(boolean ascensore) {
		this.ascensore = ascensore;
	}

	public boolean isPortineria() {
		return portineria;
	}

	public void setPortineria(boolean portineria) {
		this.portineria = portineria;
	}

	public boolean isGiardino() {
		return giardino;
	}

	public void setGiardino(boolean giardino) {
		this.giardino = giardino;
	}

	public boolean isPiscina() {
		return piscina;
	}

	public void setPiscina(boolean piscina) {
		this.piscina = piscina;
	}

	
}
