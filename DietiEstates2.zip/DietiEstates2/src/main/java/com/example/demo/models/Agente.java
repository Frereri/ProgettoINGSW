package com.example.demo.models;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name="agente", schema="dietiestates")
@AttributeOverride(name = "id", column = @Column(name = "idagente"))
public class Agente extends Utente{

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name= "idagente")
//	private Integer idAgente;
	
	@Column(name="partitaiva")
	private String partitaIva;
	
	@ManyToOne
    @JoinColumn(name = "idagenzia", nullable = false)
	private Agenzia agenzia;

	public Agente() {
		super();
	}

	public Agente(Integer idAgente, String partitaIva, Agenzia idAgenzia) {
		super();
//		this.idAgente = idAgente;
		this.partitaIva = partitaIva;
		this.agenzia = idAgenzia;
	}

//	public Integer getIdAgente() {
//		return idAgente;
//	}

//	public void setIdAgente(Integer idAgente) {
//		this.idAgente = idAgente;
//	}

	public Integer getIdAmministratore() {
		return this.getId();
	}
	
	public String getPartitaIva() {
		return partitaIva;
	}

	public void setPartitaIva(String partitaIva) {
		this.partitaIva = partitaIva;
	}

	public Agenzia getIdAgenzia() {
		return agenzia;
	}

	public void setIdAgenzia(Agenzia idAgenzia) {
		this.agenzia = idAgenzia;
	}
	
	
}
