package com.example.demo.models;


import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Inheritance;
//import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "gestore")
@AttributeOverride(name = "id", column = @Column(name = "idgestore"))
public class Gestore extends Utente{

    @ManyToOne
    @JoinColumn(name = "idamministratore", nullable = false)
	private Amministratore amministratore;

	public Gestore() {
		// TODO Auto-generated constructor stub
	}

	public Gestore(Integer idGestore, Amministratore idAmministratore) {
		super();
		this.amministratore = idAmministratore;
	}

	public Amministratore getIdAmministratore() {
		return amministratore;
	}

	public void setIdAmministratore(Amministratore idAmministratore) {
		this.amministratore = idAmministratore;
	}

	
}
