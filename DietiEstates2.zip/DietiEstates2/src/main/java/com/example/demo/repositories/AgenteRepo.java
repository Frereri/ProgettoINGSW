package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Agente;

@Repository
public interface AgenteRepo extends JpaRepository<Agente, Integer>{

	Agente findByEmail(String email);
}
