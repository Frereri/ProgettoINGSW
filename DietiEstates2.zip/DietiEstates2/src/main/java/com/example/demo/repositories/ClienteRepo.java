package com.example.demo.repositories;

public class ClienteRepo {

}
