package com.example.demo.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.Cliente;

public interface ClienteRepo extends JpaRepository<Cliente, Integer>{

	Optional<Cliente> findByEmailAndPassword(String email, String password);
	
	boolean existsByEmail(String email);
}
