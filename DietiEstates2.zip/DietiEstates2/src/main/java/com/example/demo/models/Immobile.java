package com.example.demo.models;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name="immobile")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(
		name="tipoimmobile",  
		discriminatorType = DiscriminatorType.STRING
		)
public abstract class Immobile {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idimmobile")
    private Integer idImmobile;
	
	@Column(name="titolo", nullable = false, length = 150)
    private String titolo;
	
	@Column(name="indirizzo", nullable = false, length = 200)
    private String indirizzo;
	
	@Column(name="immagine", length = 255)
    private String immagine;
    
    @Column(name="descrizione")
    private String descrizione;

    @Column(name="prezzo", nullable = false)
    private double prezzo;
    
    @Column(name="numerostanze")
    private Integer numeroStanze;
    
    @Column(name="classeenergetica", length = 5)
    private String classeEnergetica;
    
    @Column(name="climatizzazione")
    private boolean climatizzazione = false;
    
    @Column(name="boxauto")
    private boolean boxAuto = false;
    
    @Column(name="terrazzo")
    private boolean terrazzo = false;
    
    @Column(name="tipoimmobile", length = 50, insertable = false, updatable = false)
    private String tipoImmobile; 
    
    @Column(name="dimensione")
    private double dimensione;
    
    @ManyToOne
    @JoinColumn(name = "idagenzia", nullable = false)
    private Agenzia agenzia;
    
	@OneToMany(mappedBy = "immobile")
	private List<Offerta> offerte;

	public Immobile() {
		super();
	}

	public Immobile(Integer idImmobile, String titolo, String indirizzo, String immagine, String descrizione,
			double prezzo, String piano, Integer numeroStanze, String classeEnergetica, boolean ascensore,
			boolean portineria, boolean climatizzazione, boolean boxAuto, boolean terrazzo, boolean giardino,
			boolean piscina, String tipoImmobile, double dimensione, Agenzia idAgenzia, List<Offerta> offerte) {
		super();
		this.idImmobile = idImmobile;
		this.titolo = titolo;
		this.indirizzo = indirizzo;
		this.immagine = immagine;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
		this.numeroStanze = numeroStanze;
		this.classeEnergetica = classeEnergetica;
		this.climatizzazione = climatizzazione;
		this.boxAuto = boxAuto;
		this.terrazzo = terrazzo;
		this.tipoImmobile = tipoImmobile;
		this.dimensione = dimensione;
		this.agenzia = idAgenzia;
		this.offerte = offerte;
	}

	public Integer getIdImmobile() {
		return idImmobile;
	}

	public void setIdImmobile(Integer idImmobile) {
		this.idImmobile = idImmobile;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getImmagine() {
		return immagine;
	}

	public void setImmagine(String immagine) {
		this.immagine = immagine;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}

	public Integer getNumeroStanze() {
		return numeroStanze;
	}

	public void setNumeroStanze(Integer numeroStanze) {
		this.numeroStanze = numeroStanze;
	}

	public String getClasseEnergetica() {
		return classeEnergetica;
	}

	public void setClasseEnergetica(String classeEnergetica) {
		this.classeEnergetica = classeEnergetica;
	}

	public boolean isClimatizzazione() {
		return climatizzazione;
	}

	public void setClimatizzazione(boolean climatizzazione) {
		this.climatizzazione = climatizzazione;
	}

	public boolean isBoxAuto() {
		return boxAuto;
	}

	public void setBoxAuto(boolean boxAuto) {
		this.boxAuto = boxAuto;
	}

	public boolean isTerrazzo() {
		return terrazzo;
	}

	public void setTerrazzo(boolean terrazzo) {
		this.terrazzo = terrazzo;
	}

	public String getTipoImmobile() {
		return tipoImmobile;
	}

	public void setTipoImmobile(String tipoImmobile) {
		this.tipoImmobile = tipoImmobile;
	}

	public double getDimensione() {
		return dimensione;
	}

	public void setDimensione(double dimensione) {
		this.dimensione = dimensione;
	}

//	public Agenzia getIdAgenzia() {
//		return agenzia;
//	}
//
//	public void setIdAgenzia(Agenzia idAgenzia) {
//		this.agenzia = idAgenzia;
//	}
	
	public Agenzia getAgenzia() {
		return agenzia;
	}

	public void setAgenzia(Agenzia agenzia) {
		this.agenzia = agenzia;
	}

	public List<Offerta> getOfferte() {
		return offerte;
	}

	public void setOfferte(List<Offerta> offerte) {
		this.offerte = offerte;
	}

}
